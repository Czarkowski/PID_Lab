#! /bin/bash
# build tiny connector setup: generator, Kafka, connector, Cassandra

# set all parameters as variables
LIBDIR="/srv/lib"
CASSANDRA_SETUP="cassandra.cql"
KAFKA_DATA="/srv/kafka/data"
CASANDRA_DATA="/srv/cassandra/data"

# make sure all required software is present
sudo apt-get install -y ntp docker.io docker-compose >/dev/null 2>/dev/null

# stop and remove all containers
CONTAINER_LIST=$(docker ps -aq)
if [ ! -z "$CONTAINER_LIST" ]
    then
    docker stop $CONTAINER_LIST
    docker rm $CONTAINER_LIST
fi

#remove <none> images as well
docker image prune -f

# make sure directories exist
sudo rm -r -f  $KAFKA_DATA
sudo mkdir -p $KAFKA_DATA
sudo chmod 777 $KAFKA_DATA
sudo rm -r -f  "$CASANDRA_DATA"
sudo mkdir -p "$CASANDRA_DATA"
sudo chmod 777 "$CASANDRA_DATA"

# move to the work directory
cd "$LIBDIR"

# build the docker compose file
cat compose-header.yml \
    compose-tiny-kafka.yml \
    compose-tiny-generator.yml \
    compose-tiny-connector.yml \
    compose-tiny-cassandra.yml \
    > docker-compose-tiny-connector.yml

# compose and run the configuration
docker-compose \
    -f "docker-compose-tiny-connector.yml" \
    up -d --build

# wait for cassandra to settle
COUNTER=0
while [ $COUNTER -lt 20 ]
    do
    CLUSTER_UN=$(docker exec cassandra \
        cqlsh -e "describe cluster" \
        >/dev/null 2>/dev/null ;\
        echo $?)
    if (( $CLUSTER_UN == 0 )); then break; fi
    COUNTER=$(($COUNTER+1))
    echo "waiting $COUNTER"
    sleep 1
done

# execute the configuration file
docker exec cassandra \
    cqlsh -f "$LIBDIR/$CASSANDRA_SETUP"












