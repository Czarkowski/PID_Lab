#! /bin/bash
# build tiny Cassandra configuration with one node
# version 2024.03.16

# set all parameters as variables
LIBDIR="/srv/lib"
CASSANDRA_SETUP="/srv/lib/cassandra.cql"
CASSANDRA_DATA="/srv/cassandra/data"
CNAME="cassandra"

# make sure all required software is present
sudo apt-get install -y ntp docker.io >/dev/null 2>/dev/null

# stop and remove the old version of both containers
docker stop "$CNAME" 2>/dev/null
docker rm "$CNAME" 2>/dev/null
docker container prune -f 2>/dev/null

# make sure directories exist
sudo rm -r -f  "$CASSANDRA_DATA"
sudo mkdir -p "$CASSANDRA_DATA"
sudo chmod 777 "$CASSANDRA_DATA"

# run the container
docker run \
  --hostname "$CNAME" \
  --publish "9042:9042" \
  --volume "$LIBDIR:$LIBDIR" \
  --volume "$CASSANDRA_DATA:/var/lib/cassandra/data" \
  --name "$CNAME" \
  --detach \
  cassandra:3.11.14


# wait for cassandra to settle
COUNTER=0
while [ $COUNTER -lt 20 ]
    do
    CLUSTER_UN=$(docker exec $CNAME \
        cqlsh -e "describe cluster" \
        >/dev/null 2>/dev/null ;\
        echo $?)
    if (( $CLUSTER_UN == 0 )); then break; fi
    COUNTER=$(($COUNTER+1))
    echo "waiting $COUNTER"
    sleep 1
done

# execute the configuration file
docker exec $CNAME  cqlsh -f "$CASSANDRA_SETUP"








